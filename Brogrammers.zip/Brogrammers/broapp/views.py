from django.shortcuts import render,redirect
from django.contrib.auth import logout,authenticate,login
from django.contrib.auth.models import User

def home(request):
    return render(request, 'home.html')


def contact(request):
    return render(request, 'contact.html')

def login_user(request):
    return render(request, 'login.html')

def logout_user(request):
               logout(request)
               return redirect('home')

def login_user(request):
               if request.method =='POST':
                              Username=request.POST['username']
                              Password=request.POST['password']
                              user=authenticate(username=Username,password=Password)
                              if user is not None:
                                             login(request,user)
                                             return redirect('home')
                              

                            #   print(Username,Password)
               return render(request, 'login.html')

def register_user(request):
    if request.method == 'POST':
        username=request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password']
        password2 = request.POST['cpassword']
        if password1 == password2:
            if User.objects.filter(username=username).exists():
                # messages.success(request, 'This Username already Exists..!!')
                return redirect(login)
            elif User.objects.filter(email=email).exists():
                # messages.success(request, 'This Email already Exists..!!')
                return redirect(login)

            else:
                user=User.objects.create_user(username=username,email=email,password=password1)
                user.save()
                # messages.info(request,'User created Successfully..')
            return redirect(login)
        else:
            # messages.info(request,'Password Does not match')
            return redirect(login)
    return render(request, 'login.html')